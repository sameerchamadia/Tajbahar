/* =============================================================
   MughalMandala — Animated geometric mandala SVG
   Design: "Shahjahan" — Dark Imperial Grandeur
   ============================================================= */

interface MughalMandalaProps {
  size?: number;
  opacity?: number;
  className?: string;
}

export default function MughalMandala({ size = 600, opacity = 0.15, className = "" }: MughalMandalaProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 600 600"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ opacity }}
    >
      {/* Outer ring */}
      <circle cx="300" cy="300" r="290" stroke="#D4AF37" strokeWidth="0.5" strokeDasharray="4 8" />
      <circle cx="300" cy="300" r="270" stroke="#D4AF37" strokeWidth="0.3" />

      {/* 8-pointed star outer */}
      <g transform="translate(300,300)">
        {[0,45,90,135,180,225,270,315].map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <polygon
              points="0,-260 15,-220 0,-180 -15,-220"
              fill="none"
              stroke="#D4AF37"
              strokeWidth="0.6"
            />
          </g>
        ))}
      </g>

      {/* 16-pointed star mid */}
      <g transform="translate(300,300)">
        {Array.from({ length: 16 }, (_, i) => i * 22.5).map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <line x1="0" y1="-200" x2="0" y2="-160" stroke="#D4AF37" strokeWidth="0.5" />
          </g>
        ))}
      </g>

      {/* Hexagonal lattice ring */}
      <g transform="translate(300,300)">
        {Array.from({ length: 12 }, (_, i) => i * 30).map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <polygon
              points="0,-190 16,-181 16,-163 0,-154 -16,-163 -16,-181"
              fill="none"
              stroke="#D4AF37"
              strokeWidth="0.5"
            />
          </g>
        ))}
      </g>

      {/* Inner arabesque petals */}
      <g transform="translate(300,300)">
        {Array.from({ length: 8 }, (_, i) => i * 45).map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <ellipse cx="0" cy="-120" rx="18" ry="35" fill="none" stroke="#D4AF37" strokeWidth="0.6" />
          </g>
        ))}
      </g>

      {/* Inner 8-star */}
      <g transform="translate(300,300)">
        {[0,45,90,135,180,225,270,315].map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <polygon
              points="0,-90 10,-65 0,-40 -10,-65"
              fill="rgba(212,175,55,0.15)"
              stroke="#D4AF37"
              strokeWidth="0.5"
            />
          </g>
        ))}
      </g>

      {/* Concentric decorative rings */}
      <circle cx="300" cy="300" r="150" stroke="#D4AF37" strokeWidth="0.4" strokeDasharray="2 6" />
      <circle cx="300" cy="300" r="100" stroke="#D4AF37" strokeWidth="0.3" />
      <circle cx="300" cy="300" r="50" stroke="#D4AF37" strokeWidth="0.5" />
      <circle cx="300" cy="300" r="20" fill="rgba(212,175,55,0.1)" stroke="#D4AF37" strokeWidth="0.8" />

      {/* Corner ornaments at cardinal points */}
      <g transform="translate(300,300)">
        {[0,90,180,270].map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <path
              d="M 0,-240 Q 20,-230 0,-220 Q -20,-230 0,-240"
              fill="rgba(212,175,55,0.2)"
              stroke="#D4AF37"
              strokeWidth="0.5"
            />
          </g>
        ))}
      </g>

      {/* Diagonal cross lines */}
      <g transform="translate(300,300)">
        {[22.5, 67.5, 112.5, 157.5].map((angle, i) => (
          <g key={i} transform={`rotate(${angle})`}>
            <line x1="0" y1="-280" x2="0" y2="280" stroke="#D4AF37" strokeWidth="0.2" opacity="0.4" />
          </g>
        ))}
      </g>

      {/* Center dot */}
      <circle cx="300" cy="300" r="4" fill="#D4AF37" opacity="0.8" />
    </svg>
  );
}
