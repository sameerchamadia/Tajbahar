/* =============================================================
   AudioPlayer — Mughal Theme Music Control
   Design: Minimal gold controls on dark background
   ============================================================= */

import { useEffect, useRef, useState } from "react";

interface AudioPlayerProps {
  src: string;
  autoplay?: boolean;
  loop?: boolean;
  className?: string;
}

export default function AudioPlayer({ src, autoplay = true, loop = true, className = "" }: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(autoplay);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.4);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (autoplay) {
      // Attempt autoplay with user gesture fallback
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          // Autoplay failed, set to play on first user interaction
          setIsPlaying(false);
        });
      }
    }

    audio.volume = volume;
    audio.muted = isMuted;
    audio.loop = loop;
  }, [autoplay, volume, isMuted, loop]);

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  return (
    <div className={`fixed bottom-24 right-6 z-40 flex items-center gap-2 bg-[#080808]/80 backdrop-blur-md border border-[#D4AF37]/20 px-4 py-3 rounded-full ${className}`}>
      <audio ref={audioRef} src={src} preload="auto" />

      {/* Play/Pause Button */}
      <button
        onClick={togglePlayPause}
        className="w-8 h-8 flex items-center justify-center text-[#D4AF37] hover:text-[#FFD700] transition-colors"
        aria-label={isPlaying ? "Pause" : "Play"}
        title={isPlaying ? "Pause music" : "Play music"}
      >
        {isPlaying ? (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <rect x="6" y="4" width="4" height="16" />
            <rect x="14" y="4" width="4" height="16" />
          </svg>
        ) : (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <polygon points="5 3 19 12 5 21" />
          </svg>
        )}
      </button>

      {/* Volume Control */}
      <div className="flex items-center gap-2">
        <button
          onClick={toggleMute}
          className="w-6 h-6 flex items-center justify-center text-[#D4AF37] hover:text-[#FFD700] transition-colors"
          aria-label={isMuted ? "Unmute" : "Mute"}
          title={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.26 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
            </svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.26 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
            </svg>
          )}
        </button>

        {/* Volume Slider */}
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={volume}
          onChange={handleVolumeChange}
          className="w-20 h-1 bg-[#D4AF37]/20 rounded-full accent-[#D4AF37] cursor-pointer"
          aria-label="Volume"
          title="Volume control"
        />
      </div>

      {/* Label */}
      <span className="text-[#D4AF37]/50 text-xs tracking-widest font-cinzel ml-2 whitespace-nowrap">MUGHAL THEME</span>
    </div>
  );
}
