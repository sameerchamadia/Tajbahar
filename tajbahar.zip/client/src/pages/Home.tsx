/* =============================================================
   TajBahar Home Page — "Shahjahan" Design
   Dark Imperial Grandeur + Kinetic Energy
   Sections: Nav, Hero, Heritage, Products, Quality, Gallery, Certifications, Contact, Footer
   ============================================================= */

import { useEffect, useRef, useState } from "react";
import MughalMandala from "@/components/MughalMandala";
import AudioPlayer from "@/components/AudioPlayer";
import { useScrollReveal } from "@/hooks/useScrollReveal";

// Image URLs from generated assets
const IMAGES = {
  hero: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-hero-F68FLVPYQJvbzdVYSoWV6b.webp",
  music: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-mughal-theme.wav",
  heritage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-heritage-cwTUtLFZJLnHMhbgWSk4HV.webp",
  fields: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-fields-U8d5PYxt4LXFVMrQYtbaVU.webp",
  product: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-product-ivrvTHJCTSKRgAyxGS38V8.webp",
  cooking: "https://d2xsxph8kpxj0f.cloudfront.net/310519663645370242/RZ8jdC4W3seM4DaBUMyoBG/tajbahar-cooking-2qfzCytH7LoKnaBtBzPBNd.webp",
};

const PRODUCTS = [
  {
    name: "1121 Basmati",
    subtitle: "The Crown Jewel",
    description: "World's longest grain basmati, renowned for its extraordinary length and exquisite aroma. The pinnacle of premium basmati.",
    grain: "Extra Long Grain",
    aroma: "Intense Floral",
    cookTime: "18–20 min",
    icon: "♛",
  },
  {
    name: "Traditional Basmati",
    subtitle: "Heritage Reserve",
    description: "The original, time-honored variety cultivated in the foothills of the Himalayas for over five centuries of royal tradition.",
    grain: "Long Grain",
    aroma: "Classic Nutty",
    cookTime: "15–18 min",
    icon: "◈",
  },
  {
    name: "Steam Basmati",
    subtitle: "Artisan Process",
    description: "Steam-processed to lock in nutrients and natural fragrance, delivering perfect grain separation with every cook.",
    grain: "Long Grain",
    aroma: "Delicate Floral",
    cookTime: "12–15 min",
    icon: "❋",
  },
  {
    name: "Sella Basmati",
    subtitle: "Golden Parboiled",
    description: "Parboiled to golden perfection, retaining maximum nutrition while offering superior firmness and a rich amber hue.",
    grain: "Long Grain",
    aroma: "Earthy & Rich",
    cookTime: "20–25 min",
    icon: "✦",
  },
  {
    name: "1509 Basmati",
    subtitle: "Modern Classic",
    description: "A newer premium variety combining the best of length, aroma, and yield — the choice of discerning global chefs.",
    grain: "Extra Long Grain",
    aroma: "Mild & Fragrant",
    cookTime: "15–18 min",
    icon: "◉",
  },
  {
    name: "Pusa Basmati",
    subtitle: "Scientific Excellence",
    description: "Developed through advanced agronomy, Pusa delivers consistent quality and superior yield without compromising heritage.",
    grain: "Long Grain",
    aroma: "Subtle Floral",
    cookTime: "14–16 min",
    icon: "⬡",
  },
];

const CERTIFICATIONS = [
  { name: "ISO 22000", desc: "Food Safety Management", icon: "🏅" },
  { name: "FSSAI", desc: "Food Safety Standards India", icon: "🇮🇳" },
  { name: "APEDA", desc: "Agricultural Export Authority", icon: "📋" },
  { name: "Halal Certified", desc: "Global Halal Compliance", icon: "☪" },
  { name: "GI Tag", desc: "Geographical Indication", icon: "📍" },
  { name: "HACCP", desc: "Hazard Analysis Control", icon: "🔬" },
];

const PROCESS_STEPS = [
  { num: "01", title: "Field Selection", desc: "Sourced from certified farms in the Himalayan foothills of Punjab and Haryana" },
  { num: "02", title: "Careful Harvesting", desc: "Hand-selected at peak maturity to preserve grain integrity and natural aroma" },
  { num: "03", title: "Precision Milling", desc: "State-of-the-art processing that maintains grain length and nutritional value" },
  { num: "04", title: "Quality Testing", desc: "Multi-stage laboratory testing against international food safety standards" },
  { num: "05", title: "Royal Packaging", desc: "Vacuum-sealed in premium packaging to lock in freshness for global export" },
];

export default function Home() {
  useScrollReveal();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [formData, setFormData] = useState({
    name: "", company: "", email: "", phone: "", product: "", quantity: "", message: ""
  });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Enhanced parallax effect on hero
  useEffect(() => {
    const handleParallax = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY;
        const parallaxIntensity = 0.5;
        const rotation = scrollY * 0.02;
        heroRef.current.style.transform = `translateY(${scrollY * parallaxIntensity}px) scale(${1 + scrollY * 0.0005})`;
        heroRef.current.style.filter = `brightness(${1 - scrollY * 0.0008})`;
      }
    };
    window.addEventListener("scroll", handleParallax);
    return () => window.removeEventListener("scroll", handleParallax);
  }, []);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => setFormSubmitted(false), 5000);
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#080808] text-[#F5E6C8] overflow-x-hidden">

      {/* ===== NAVIGATION ===== */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "bg-[#080808]/95 backdrop-blur-md border-b border-[#D4AF37]/15 py-3" : "bg-transparent py-5"}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <button onClick={() => scrollTo("hero")} className="flex flex-col items-start">
            <span className="font-cinzel-decorative text-[#D4AF37] text-xl font-bold tracking-wider leading-none">TAJ BAHAR</span>
            <span className="font-raleway text-[#D4AF37]/50 text-[9px] tracking-[0.4em] uppercase mt-0.5">by Texstar Global</span>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {["heritage", "products", "quality", "gallery", "contact"].map((item) => (
              <button key={item} onClick={() => scrollTo(item)} className="nav-link">
                {item}
              </button>
            ))}
          </div>

          {/* CTA */}
          <button
            onClick={() => scrollTo("contact")}
            className="hidden md:block btn-gold text-xs"
          >
            Bulk Inquiry
          </button>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <span className={`block w-6 h-px bg-[#D4AF37] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-6 h-px bg-[#D4AF37] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-px bg-[#D4AF37] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden transition-all duration-400 overflow-hidden ${menuOpen ? "max-h-80 border-t border-[#D4AF37]/15" : "max-h-0"}`}>
          <div className="bg-[#0a0a0a]/98 backdrop-blur-md px-6 py-4 flex flex-col gap-4">
            {["heritage", "products", "quality", "gallery", "contact"].map((item) => (
              <button key={item} onClick={() => scrollTo(item)} className="nav-link text-left py-1">
                {item}
              </button>
            ))}
            <button onClick={() => scrollTo("contact")} className="btn-gold text-xs mt-2">
              Bulk Inquiry
            </button>
          </div>
        </div>
      </nav>

      {/* ===== HERO SECTION ===== */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background image with parallax */}
        <div className="absolute inset-0 overflow-hidden">
          <div ref={heroRef} className="absolute inset-0 scale-110">
            <img
              src={IMAGES.hero}
              alt="Premium Basmati Rice"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#080808]/70 via-[#080808]/40 to-[#080808]/90" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080808]/60 via-transparent to-[#080808]/60" />
          </div>
        </div>

        {/* Animated Mandala — mobile center faint */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-rotate-slow pointer-events-none lg:hidden">
          <MughalMandala size={400} opacity={0.06} />
        </div>

        {/* Animated Mandala — left */}
        <div className="absolute -left-32 top-1/2 -translate-y-1/2 animate-rotate-slow pointer-events-none hidden lg:block">
          <MughalMandala size={500} opacity={0.12} />
        </div>

        {/* Animated Mandala — right */}
        <div className="absolute -right-32 top-1/2 -translate-y-1/2 animate-rotate-slow-reverse pointer-events-none hidden lg:block">
          <MughalMandala size={500} opacity={0.12} />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
          {/* Pre-title */}
          <div className="ornament-divider mb-8 animate-fade-up" style={{ animationDelay: "0.2s" }}>
            <span className="section-label">Est. Texstar Global · Premium Export</span>
          </div>

          {/* Main Title */}
          <h1
            className="font-cinzel text-6xl md:text-8xl lg:text-9xl font-black text-gold-shimmer leading-none mb-4 animate-fade-up"
            style={{ animationDelay: "0.4s" }}
          >
            TAJ BAHAR
          </h1>

          {/* Tagline */}
          <p
            className="font-playfair text-2xl md:text-3xl lg:text-4xl italic text-[#F5E6C8] mb-8 animate-fade-up"
            style={{ animationDelay: "0.6s" }}
          >
            "The Essence of Royal Basmati"
          </p>

          {/* Sub-tagline */}
          <p
            className="font-raleway text-[#D4AF37]/70 text-sm md:text-base tracking-widest uppercase mb-12 animate-fade-up"
            style={{ animationDelay: "0.8s" }}
          >
            Premium Export-Grade Basmati · Inspired by Mughal Heritage
          </p>

          {/* CTAs */}
          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up"
            style={{ animationDelay: "1s" }}
          >
            <button onClick={() => scrollTo("products")} className="btn-gold">
              Explore Varieties
            </button>
            <button onClick={() => scrollTo("contact")} className="btn-gold-outline">
              Request a Sample
            </button>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
            <span className="section-label text-[10px]">Scroll</span>
            <div className="w-px h-12 bg-gradient-to-b from-[#D4AF37]/60 to-transparent" />
          </div>
        </div>
      </section>

      {/* ===== STATS BAR ===== */}
      <section className="relative z-10 bg-[#0D0D0D] border-y border-[#D4AF37]/15 py-8">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-0 md:divide-x md:divide-[#D4AF37]/15">
            {[
              { value: "25+", label: "Countries Exported" },
              { value: "6", label: "Premium Varieties" },
              { value: "ISO", label: "22000 Certified" },
              { value: "100%", label: "Export Grade Quality" },
            ].map((stat, i) => (
              <div key={i} className="text-center px-6 reveal stagger-children">
                <div className="font-cinzel text-3xl md:text-4xl text-gold-gradient font-bold mb-1">{stat.value}</div>
                <div className="section-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== HERITAGE SECTION ===== */}
      <section id="heritage" className="relative py-24 md:py-36 overflow-hidden">
        {/* Geo pattern background */}
        <div className="absolute inset-0 geo-pattern opacity-50" />

        <div className="relative max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image side */}
            <div className="relative reveal">
              <div className="relative overflow-hidden" style={{ clipPath: "polygon(0 0, 92% 0, 100% 8%, 100% 100%, 8% 100%, 0 92%)" }}>
                <img
                  src={IMAGES.heritage}
                  alt="Mughal Heritage"
                  className="w-full h-[500px] md:h-[600px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/60 via-transparent to-transparent" />
              </div>
              {/* Decorative corner frames */}
              <div className="absolute -top-4 -left-4 w-16 h-16 border-t-2 border-l-2 border-[#D4AF37]/60" />
              <div className="absolute -bottom-4 -right-4 w-16 h-16 border-b-2 border-r-2 border-[#D4AF37]/60" />
              {/* Floating badge */}
              <div className="absolute bottom-8 left-8 bg-[#080808]/90 border border-[#D4AF37]/40 px-5 py-3 backdrop-blur-sm">
                <div className="font-cinzel text-[#D4AF37] text-xs tracking-widest">SINCE ANTIQUITY</div>
                <div className="font-playfair text-[#F5E6C8] text-lg italic mt-0.5">Mughal Legacy</div>
              </div>
            </div>

            {/* Content side */}
            <div className="reveal" style={{ transitionDelay: "0.2s" }}>
              <div className="section-label mb-4">Our Heritage</div>
              <h2 className="font-cinzel text-4xl md:text-5xl text-gold-gradient font-bold mb-6 leading-tight">
                Where Royalty<br />Meets the Grain
              </h2>
              <div className="w-24 h-px bg-gradient-to-r from-[#D4AF37] to-transparent mb-8" />

              <p className="font-playfair text-[#F5E6C8]/80 text-lg italic leading-relaxed mb-6">
                "In the courts of the Mughal emperors, basmati rice was not merely sustenance — it was ceremony, artistry, and the very soul of Indian hospitality."
              </p>

              <p className="font-raleway text-[#F5E6C8]/65 leading-relaxed mb-6">
                TajBahar carries this centuries-old legacy forward. Cultivated in the fertile plains beneath the Himalayas — where the Ganges nourishes the soil and cool mountain breezes carry the fragrance of the harvest — our rice embodies the very essence of Indian heritage.
              </p>

              <p className="font-raleway text-[#F5E6C8]/65 leading-relaxed mb-10">
                Texstar Global brings this royal grain to tables across the world, maintaining the artisanal integrity of traditional cultivation while meeting the highest international food safety standards.
              </p>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { title: "Himalayan Origin", desc: "Sourced from the foothills of the Himalayas" },
                  { title: "Aged to Perfection", desc: "Naturally aged to deepen aroma and flavor" },
                  { title: "Artisanal Process", desc: "Traditional methods meet modern precision" },
                  { title: "World Export", desc: "Trusted by importers across 25+ nations" },
                ].map((item, i) => (
                  <div key={i} className="cert-badge p-4">
                    <div className="font-cinzel text-[#D4AF37] text-xs tracking-wider mb-1">{item.title}</div>
                    <div className="font-raleway text-[#F5E6C8]/55 text-xs leading-relaxed">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== PRODUCTS SECTION ===== */}
      <section id="products" className="relative py-24 md:py-36 bg-[#0A0A0A] overflow-hidden">
        {/* Background mandala */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
          <MughalMandala size={900} opacity={0.04} />
        </div>

        <div className="relative max-w-7xl mx-auto px-6">
          {/* Section header */}
          <div className="text-center mb-16 reveal">
            <div className="section-label mb-4">Our Collection</div>
            <h2 className="font-cinzel text-4xl md:text-6xl text-gold-gradient font-bold mb-4">
              Royal Varieties
            </h2>
            <p className="font-playfair text-[#F5E6C8]/60 text-lg italic max-w-2xl mx-auto">
              Six expressions of basmati excellence, each with its own character, aroma, and story
            </p>
          </div>

          {/* Products grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 stagger-children">
            {PRODUCTS.map((product, i) => (
              <div key={i} className="product-card p-8 reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                {/* Icon */}
                <div className="text-4xl text-[#D4AF37] mb-4 font-cinzel">{product.icon}</div>

                {/* Name */}
                <div className="section-label mb-1">{product.subtitle}</div>
                <h3 className="font-cinzel text-xl text-[#F5E6C8] font-bold mb-3">{product.name}</h3>

                {/* Divider */}
                <div className="w-12 h-px bg-[#D4AF37]/40 mb-4" />

                {/* Description */}
                <p className="font-raleway text-[#F5E6C8]/55 text-sm leading-relaxed mb-6">
                  {product.description}
                </p>

                {/* Specs */}
                <div className="space-y-2">
                  {[
                    { label: "Grain", value: product.grain },
                    { label: "Aroma", value: product.aroma },
                    { label: "Cook Time", value: product.cookTime },
                  ].map((spec, j) => (
                    <div key={j} className="flex justify-between items-center">
                      <span className="font-raleway text-[#D4AF37]/50 text-xs tracking-wider uppercase">{spec.label}</span>
                      <span className="font-raleway text-[#F5E6C8]/70 text-xs">{spec.value}</span>
                    </div>
                  ))}
                </div>

                {/* Bottom border accent */}
                <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent" />
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="text-center mt-12 reveal">
            <button onClick={() => scrollTo("contact")} className="btn-gold-outline">
              Inquire About Bulk Orders
            </button>
          </div>
        </div>
      </section>

      {/* ===== QUALITY & PROCESS SECTION ===== */}
      <section id="quality" className="relative py-24 md:py-36 overflow-hidden">
        {/* Parallax background */}
        <div className="absolute inset-0">
          <img
            src={IMAGES.fields}
            alt="Rice Fields"
            className="w-full h-full object-cover parallax-bg"
          />
          <div className="absolute inset-0 bg-[#080808]/85" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#080808]/60 via-transparent to-[#080808]/60" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6">
          {/* Section header */}
          <div className="text-center mb-20 reveal">
            <div className="section-label mb-4">From Field to Table</div>
            <h2 className="font-cinzel text-4xl md:text-6xl text-gold-gradient font-bold mb-4">
              The Royal Process
            </h2>
            <p className="font-playfair text-[#F5E6C8]/60 text-lg italic max-w-2xl mx-auto">
              Every grain of TajBahar passes through a meticulous journey of care, precision, and heritage
            </p>
          </div>

          {/* Process steps */}
          <div className="grid md:grid-cols-5 gap-8 md:gap-4">
            {PROCESS_STEPS.map((step, i) => (
              <div key={i} className="text-center reveal" style={{ transitionDelay: `${i * 0.15}s` }}>
                {/* Number */}
                <div className="relative inline-flex items-center justify-center w-16 h-16 mb-4 mx-auto">
                  <div className="absolute inset-0 border border-[#D4AF37]/30 rotate-45" />
                  <span className="font-cinzel text-[#D4AF37] text-lg font-bold relative z-10">{step.num}</span>
                </div>

                {/* Connector line (desktop) */}
                {i < PROCESS_STEPS.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-[calc(50%+2rem)] right-[calc(-50%+2rem)] h-px bg-gradient-to-r from-[#D4AF37]/40 to-[#D4AF37]/10" style={{ position: "relative", top: "-3.5rem", marginBottom: "-1rem" }} />
                )}

                <h3 className="font-cinzel text-[#F5E6C8] text-sm font-bold tracking-wider mb-3">{step.title}</h3>
                <p className="font-raleway text-[#F5E6C8]/50 text-xs leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>

          {/* Quality promise */}
          <div className="mt-20 grid md:grid-cols-3 gap-6">
            {[
              { title: "Zero Compromise", desc: "Every batch tested against 47 quality parameters before export approval", icon: "◈" },
              { title: "Cold-Chain Integrity", desc: "Temperature-controlled storage preserving aroma from mill to port", icon: "❋" },
              { title: "Traceability", desc: "Full farm-to-ship traceability for every consignment we export", icon: "✦" },
            ].map((item, i) => (
              <div key={i} className="cert-badge p-6 text-center reveal" style={{ transitionDelay: `${i * 0.15}s` }}>
                <div className="font-cinzel text-[#D4AF37] text-2xl mb-3">{item.icon}</div>
                <h3 className="font-cinzel text-[#F5E6C8] text-sm font-bold tracking-wider mb-2">{item.title}</h3>
                <p className="font-raleway text-[#F5E6C8]/50 text-xs leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== GALLERY SECTION ===== */}
      <section id="gallery" className="relative py-24 md:py-36 bg-[#0A0A0A] overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          {/* Section header */}
          <div className="text-center mb-16 reveal">
            <div className="section-label mb-4">Visual Journey</div>
            <h2 className="font-cinzel text-4xl md:text-6xl text-gold-gradient font-bold mb-4">
              A Feast for the Senses
            </h2>
          </div>

          {/* Gallery grid — asymmetric layout */}
          <div className="grid grid-cols-12 grid-rows-2 gap-4 h-[600px] md:h-[700px]">
            {/* Large left */}
            <div className="col-span-12 md:col-span-7 row-span-2 relative overflow-hidden reveal group">
              <img
                src={IMAGES.cooking}
                alt="Royal Basmati Served"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/70 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6">
                <div className="section-label mb-1">Culinary Excellence</div>
                <p className="font-playfair text-[#F5E6C8] text-xl italic">Perfection in every grain</p>
              </div>
              <div className="absolute inset-0 border border-[#D4AF37]/0 group-hover:border-[#D4AF37]/30 transition-all duration-500" />
            </div>

            {/* Top right */}
            <div className="col-span-12 md:col-span-5 row-span-1 relative overflow-hidden reveal group" style={{ transitionDelay: "0.2s" }}>
              <img
                src={IMAGES.product}
                alt="Rice Varieties"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4">
                <p className="font-cinzel text-[#D4AF37] text-xs tracking-widest">Six Premium Varieties</p>
              </div>
              <div className="absolute inset-0 border border-[#D4AF37]/0 group-hover:border-[#D4AF37]/30 transition-all duration-500" />
            </div>

            {/* Bottom right */}
            <div className="col-span-12 md:col-span-5 row-span-1 relative overflow-hidden reveal group" style={{ transitionDelay: "0.3s" }}>
              <img
                src={IMAGES.heritage}
                alt="Mughal Heritage"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080808]/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4">
                <p className="font-cinzel text-[#D4AF37] text-xs tracking-widest">Mughal Heritage</p>
              </div>
              <div className="absolute inset-0 border border-[#D4AF37]/0 group-hover:border-[#D4AF37]/30 transition-all duration-500" />
            </div>
          </div>
        </div>
      </section>

      {/* ===== CERTIFICATIONS SECTION ===== */}
      <section className="relative py-20 border-y border-[#D4AF37]/10 overflow-hidden">
        <div className="absolute inset-0 geo-pattern opacity-30" />

        <div className="relative max-w-6xl mx-auto px-6">
          <div className="text-center mb-12 reveal">
            <div className="section-label mb-4">Internationally Recognized</div>
            <h2 className="font-cinzel text-3xl md:text-4xl text-gold-gradient font-bold">
              Certified Excellence
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 stagger-children">
            {CERTIFICATIONS.map((cert, i) => (
              <div key={i} className="cert-badge p-5 text-center reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                <div className="text-2xl mb-2">{cert.icon}</div>
                <div className="font-cinzel text-[#D4AF37] text-xs font-bold tracking-wider mb-1">{cert.name}</div>
                <div className="font-raleway text-[#F5E6C8]/40 text-[10px] leading-tight">{cert.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CONTACT SECTION ===== */}
      <section id="contact" className="relative py-24 md:py-36 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0D0D0D] via-[#080808] to-[#0D0D0D]" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-full bg-gradient-to-b from-transparent via-[#D4AF37]/10 to-transparent" />
        </div>

        {/* Mandala background */}
        <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/3 pointer-events-none opacity-5">
          <MughalMandala size={700} opacity={1} />
        </div>

        <div className="relative max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Left: Contact info */}
            <div className="reveal">
              <div className="section-label mb-4">Get in Touch</div>
              <h2 className="font-cinzel text-4xl md:text-5xl text-gold-gradient font-bold mb-6 leading-tight">
                Partner With<br />Royalty
              </h2>
              <div className="w-24 h-px bg-gradient-to-r from-[#D4AF37] to-transparent mb-8" />

              <p className="font-raleway text-[#F5E6C8]/60 leading-relaxed mb-10">
                Whether you are a distributor, importer, restaurant chain, or retail buyer — TajBahar offers flexible bulk supply with consistent quality and reliable export logistics. Let us bring the essence of royal basmati to your market.
              </p>

              {/* Contact details */}
              <div className="space-y-5 mb-10">
                {[
                  { label: "Company", value: "Texstar Global", icon: "🏢" },
                  { label: "Email", value: "info@texstarglobal.com", icon: "✉", href: "mailto:info@texstarglobal.com" },
                  { label: "Phone", value: "+1 832 754 0922", icon: "📞", href: "tel:+18327540922" },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <div className="w-10 h-10 border border-[#D4AF37]/30 flex items-center justify-center text-sm flex-shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <div className="section-label text-[10px] mb-0.5">{item.label}</div>
                      {item.href ? (
                        <a href={item.href} className="font-raleway text-[#F5E6C8]/80 hover:text-[#D4AF37] transition-colors">
                          {item.value}
                        </a>
                      ) : (
                        <span className="font-raleway text-[#F5E6C8]/80">{item.value}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* WhatsApp CTA */}
              <a
                href="https://wa.me/18327540922?text=Hello%20TajBahar%2C%20I%20am%20interested%20in%20bulk%20basmati%20rice%20inquiry."
                target="_blank"
                rel="noopener noreferrer"
                className="whatsapp-btn inline-flex items-center gap-3 px-6 py-3 font-cinzel text-sm tracking-wider"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Chat on WhatsApp
              </a>
            </div>

            {/* Right: Inquiry form */}
            <div className="reveal" style={{ transitionDelay: "0.2s" }}>
              <div className="border border-[#D4AF37]/20 p-8 relative">
                {/* Corner accents */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[#D4AF37]/60" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[#D4AF37]/60" />

                <h3 className="font-cinzel text-xl text-[#D4AF37] font-bold tracking-wider mb-6">
                  Bulk Inquiry Form
                </h3>

                {formSubmitted ? (
                  <div className="text-center py-12">
                    <div className="font-cinzel text-[#D4AF37] text-4xl mb-4">✦</div>
                    <h4 className="font-cinzel text-[#F5E6C8] text-lg mb-2">Inquiry Received</h4>
                    <p className="font-raleway text-[#F5E6C8]/55 text-sm">
                      Our team will contact you within 24 hours. Thank you for choosing TajBahar.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Your Name *</label>
                        <input
                          type="text"
                          name="name"
                          required
                          value={formData.name}
                          onChange={handleFormChange}
                          placeholder="Full name"
                          className="taj-input"
                        />
                      </div>
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Company</label>
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleFormChange}
                          placeholder="Company name"
                          className="taj-input"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Email *</label>
                        <input
                          type="email"
                          name="email"
                          required
                          value={formData.email}
                          onChange={handleFormChange}
                          placeholder="your@email.com"
                          className="taj-input"
                        />
                      </div>
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Phone</label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleFormChange}
                          placeholder="+1 000 000 0000"
                          className="taj-input"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Product Interest</label>
                        <select
                          name="product"
                          value={formData.product}
                          onChange={handleFormChange}
                          className="taj-input"
                        >
                          <option value="" className="bg-[#0a0a0a]">Select variety</option>
                          <option value="1121" className="bg-[#0a0a0a]">1121 Basmati</option>
                          <option value="traditional" className="bg-[#0a0a0a]">Traditional Basmati</option>
                          <option value="steam" className="bg-[#0a0a0a]">Steam Basmati</option>
                          <option value="sella" className="bg-[#0a0a0a]">Sella Basmati</option>
                          <option value="1509" className="bg-[#0a0a0a]">1509 Basmati</option>
                          <option value="pusa" className="bg-[#0a0a0a]">Pusa Basmati</option>
                          <option value="mixed" className="bg-[#0a0a0a]">Mixed / Multiple</option>
                        </select>
                      </div>
                      <div>
                        <label className="section-label text-[10px] block mb-1.5">Quantity (MT)</label>
                        <input
                          type="text"
                          name="quantity"
                          value={formData.quantity}
                          onChange={handleFormChange}
                          placeholder="e.g. 20 MT"
                          className="taj-input"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="section-label text-[10px] block mb-1.5">Message</label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleFormChange}
                        placeholder="Tell us about your requirements, destination country, and any specific needs..."
                        rows={4}
                        className="taj-input resize-none"
                      />
                    </div>

                    <button type="submit" className="btn-gold w-full mt-2">
                      Submit Inquiry
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="relative bg-[#050505] border-t border-[#D4AF37]/15 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 mb-10">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="font-cinzel-decorative text-[#D4AF37] text-2xl font-bold tracking-wider mb-2">TAJ BAHAR</div>
              <div className="font-raleway text-[#D4AF37]/40 text-xs tracking-widest uppercase mb-4">by Texstar Global</div>
              <p className="font-raleway text-[#F5E6C8]/40 text-sm leading-relaxed max-w-xs">
                Premium export-grade basmati rice from India, inspired by Mughal heritage and crafted for the world's finest tables.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <div className="section-label mb-4">Navigate</div>
              <div className="space-y-2">
                {["Heritage", "Products", "Quality", "Gallery", "Contact"].map((link) => (
                  <button
                    key={link}
                    onClick={() => scrollTo(link.toLowerCase())}
                    className="block font-raleway text-[#F5E6C8]/40 hover:text-[#D4AF37] text-sm transition-colors"
                  >
                    {link}
                  </button>
                ))}
              </div>
            </div>

            {/* Contact */}
            <div>
              <div className="section-label mb-4">Contact</div>
              <div className="space-y-3">
                <a href="mailto:info@texstarglobal.com" className="block font-raleway text-[#F5E6C8]/40 hover:text-[#D4AF37] text-sm transition-colors">
                  info@texstarglobal.com
                </a>
                <a href="tel:+18327540922" className="block font-raleway text-[#F5E6C8]/40 hover:text-[#D4AF37] text-sm transition-colors">
                  +1 832 754 0922
                </a>
                <a
                  href="https://wa.me/18327540922"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 font-raleway text-[#25D366] hover:text-[#25D366]/80 text-sm transition-colors"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  WhatsApp
                </a>
              </div>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="border-t border-[#D4AF37]/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="font-raleway text-[#F5E6C8]/25 text-xs">
              © 2024 Texstar Global. All rights reserved. TajBahar is a registered brand.
            </p>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-[#D4AF37]/40" />
              <span className="font-cinzel text-[#D4AF37]/30 text-[10px] tracking-widest">THE ESSENCE OF ROYAL BASMATI</span>
              <div className="w-1 h-1 rounded-full bg-[#D4AF37]/40" />
            </div>
          </div>
        </div>
      </footer>

      {/* Audio Player */}
      <AudioPlayer src={IMAGES.music} autoplay={true} loop={true} />

      {/* Floating WhatsApp button */}
      <a
        href="https://wa.me/18327540922?text=Hello%20TajBahar%2C%20I%20am%20interested%20in%20bulk%20basmati%20rice%20inquiry."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] flex items-center justify-center shadow-lg hover:bg-[#128C7E] transition-all duration-300 hover:scale-110 hover:shadow-[0_0_20px_rgba(37,211,102,0.4)] wa-pulse"
        aria-label="Chat on WhatsApp"
        style={{ borderRadius: "50%" }}
      >
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
    </div>
  );
}
